#!/bin/sh

./EM_mapper.py < untagged | ./EM_reducer.py
