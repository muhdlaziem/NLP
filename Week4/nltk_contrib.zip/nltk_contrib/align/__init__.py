# Natural Language Toolkit: Aligners
#
# Copyright (C) 2001-2011 NLTK Project
# Author: 
# URL: <http://www.nltk.org/>
# For license information, see LICENSE.TXT

"""
Classes and interfaces for aligning text.
"""

from api import *
from gale_church import *

__all__ = []

