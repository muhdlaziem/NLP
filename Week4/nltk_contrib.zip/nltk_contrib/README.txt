Status of NLTK-Contrib Projects
-------------------------------

nltk.demo/app/projects = new home for mature packages that aren't libraries
               installed in user space?

agreement
bioreader			MIGRATE into nltk.corpus
ccg					MIGRATE [merge into nltk.parse, or a new package?]					
classifier*			investigate
classify			REMOVE? [outdated by nltk.classify]
combined.py
concord.py			MIGRATE into a new nltk.concordance package
coref				MIGRATE to nltk.corpus [Sep?]
dependency			FOLD into depparser
depparser			MIGRATE [Sep?]
featuredemo.py		MIGRATE into nltk.draw?
fst					MIGRATE?
fuf					MIGRATE [Sep?]
gluesemantics		REMOVE [once migration into nltk.sem is complete]
hadoop				investigate
hole.py				MIGRATE
lambek				nltk.project?
lpath				nltk.project?
mit					MIGRATE [rspeer to advise]
rdf.py
readability			nltk.project?
referring.py
rte
sem					REMOVE? [dhgarrette to advise]
seqclass.py
speer.cfg			move to mit? [rspeer to advise]
stringcomp.py
tag
test2.cfg
test2.out
timex.py			MIGRATE into a new normalize package?
tnt.py				MIGRATE into nltk.tag?
toolbox				nltk.project?
wordnet				REMOVE? [pbone to advise]
