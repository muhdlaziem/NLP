#!/bin/bash

python ./alltests.py

