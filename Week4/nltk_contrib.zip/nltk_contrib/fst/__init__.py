"""
Finite state transducer support, including graphical display & demo,
and interface code for AT&T fsmtools.
"""
